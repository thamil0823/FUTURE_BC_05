import CoinList from './components/CoinList';
import PortfolioSummary from './components/PortfolioSummary';

export default function App() {
  const holdings = { bitcoin: 0.5, ethereum: 1, solana: 5 };
  return (
    <div style={{ padding: '20px' }}>
      <h1>My Crypto Portfolio</h1>
      <PortfolioSummary holdings={holdings} />
      <CoinList holdings={holdings} />
    </div>
  );
}

