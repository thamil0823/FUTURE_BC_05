import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function CoinList({ holdings }) {
  const [coins, setCoins] = useState([]);

  useEffect(() => {
    const fetch = async () => {
      try {
        const { data } = await axios.get(
          'https://api.coingecko.com/api/v3/coins/markets',
          {
            params: {
              vs_currency: 'usd',
              ids: Object.keys(holdings).join(','),
              sparkline: false
            }
          }
        );
        setCoins(data);
      } catch (error) {
        console.error('Error fetching coin data:', error);
      }
    };

    fetch();                     // Initial fetch
    const interval = setInterval(fetch, 60_000); // Refresh every minute
    return () => clearInterval(interval);
  }, [holdings]);

  return (
    <ul style={{ listStyle: 'none', padding: 0 }}>
      {coins.map(c => (
        <li key={c.id} style={{ marginBottom: '10px' }}>
          <strong>{c.name}</strong>: ${c.current_price} × {holdings[c.id]} = $
          {(c.current_price * holdings[c.id]).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

