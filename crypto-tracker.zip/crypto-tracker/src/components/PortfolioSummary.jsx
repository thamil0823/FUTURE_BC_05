import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function PortfolioSummary({ holdings }) {
  const [total, setTotal] = useState(0);

  useEffect(() => {
    const fetchPrices = async () => {
      const ids = Object.keys(holdings).join(',');
      const { data } = await axios.get('https://api.coingecko.com/api/v3/simple/price', {
        params: { ids, vs_currencies: 'usd' }
      });
      let sum = 0;
      for (const id of Object.keys(holdings)) {
        sum += holdings[id] * (data[id]?.usd || 0);
      }
      setTotal(sum);
    };
    fetchPrices();
  }, [holdings]);

  return <h2>Total Portfolio Value: ${total.toFixed(2)}</h2>;
}

